console.log('hola mundo');
console.log('soy el primer script');