#EJERCICIO 7: Formularios y validación de datos

Construir un formulario de registro como el de la imagen, usando los elementos y clases de Bootstrap.

Los campos deben estar distribuidos en dos columnas, pero en pantallas pequeñas debe haber una única columna, es decir: los inputs deben ocupar el 100% del width de la ventana. Usad las clases grid de Bootstrap con el breakpoint sm ("small") para lograr esto.

Por último, añadid validación al formulario. Para este ejercicio, basta con conseguir que todos los campos sean obligatorios y que salga un mensaje de error en rojo en los campos que no se han rellenado, tal como pasa en los ejemplos de la documentación de Bootstrap.
