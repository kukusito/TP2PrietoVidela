var usuario = "Nestor Kirchner";

alert('Hola ' + usuario);