if (confirm("Presione un boton")) {
    console.log('has clickado OK')
} else {
    console.log('has clickado cancelar')
}